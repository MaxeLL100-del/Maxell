# QA REPORT — MAXELL GAMES 1.0.0

**Status:** PARTIALLY VERIFIED  
**Tanggal:** 13 Oktober 2026  
**Tujuan laporan:** membedakan pemeriksaan yang benar-benar dijalankan dari verifikasi yang membutuhkan origin hosting/perangkat nyata.

## 1. Ringkasan hasil

- **18/18 mini-game berhasil di-mount** dalam harness browser Chromium dan menerima jalur interaksi dasar tanpa uncaught JavaScript error.
- Pencarian, kategori puzzle (5 item), filter favorit, dan pemulihan katalog ke 18 item teruji.
- Completion test berhasil untuk Rock/Paper/Scissors (5 ronde), Quick Math (10 jawaban benar), dan Reflex Overdrive; skor tersimpan ke `localStorage` pada harness.
- Dialog dapat ditutup melalui `Escape`.
- Pemeriksaan viewport 320, 360, 390, 430, 650, 768, 1024, dan 1365 px tidak menemukan horizontal overflow setelah layout settle pada harness inline.
- Syntax check Node.js untuk `app.js` dan `service-worker.js` berhasil.
- **Offline reload/service worker pada origin sebenarnya belum diverifikasi.** Kebijakan lingkungan Chromium menolak navigasi ke URL lokal (`ERR_BLOCKED_BY_ADMINISTRATOR`), jadi pengujian runtime dijalankan dengan markup, CSS, dan JavaScript yang diinjeksi langsung ke halaman browser. Ini bukan pengganti uji HTTPS pada InfinityFree.

## 2. Lingkungan dan metode

| Area | Lingkungan/metode | Hasil |
|---|---|---|
| JavaScript parse | Node.js `v22.16.0`, `node --check app.js` | PASSED |
| Service worker parse | Node.js `v22.16.0`, `node --check service-worker.js` | PASSED |
| Browser smoke test | Chromium headless melalui Playwright; sumber HTML/CSS/JS disatukan ke halaman uji inline | PASSED pada ruang lingkup di bawah |
| Pengujian file melalui origin HTTP pada browser | Navigasi browser lokal ditolak kebijakan runtime | BLOCKED |
| Offline/PWA cache test | Memerlukan worker aktif pada secure origin dan reload offline | BLOCKED / NOT TESTED |
| Pengujian InfinityFree | Tidak ada domain/hosting pengguna yang di-deploy dari sesi ini | NOT TESTED |
| Perangkat fisik Android/iOS/desktop | Tidak tersedia pengukuran perangkat fisik pada sesi ini | NOT TESTED |

## 3. Functional test results

| ID | Tes | Langkah inti | Hasil aktual | Status |
|---|---|---|---|---|
| F-01 | Initial render | Load DOM dan jalankan app JS | Judul `MAXELL GAMES — Local Arcade`; 18 kartu ter-render | PASSED |
| F-02 | Search | Cari `snake`, kemudian kosongkan | Hasil pencarian pertama hanya menampilkan Neon Snake | PASSED |
| F-03 | Category | Pilih kategori Puzzle | Menampilkan 5 game puzzle | PASSED |
| F-04 | Favorites | Toggle favorit Snake, tampilkan favorit saja | Hanya game favorit ditampilkan; katalog kembali menjadi 18 saat filter dimatikan | PASSED |
| F-05 | Game mount | Buka seluruh ID: snake, pong, breakout, space, 2048, memory, mines, lights, tictactoe, connect4, rps, number, reaction, simon, math, whack, word, color | 18 game berhasil membuka panel gameplay | PASSED |
| F-06 | Basic interaction sweep | Restart/tekan input utama tiap game, termasuk keyboard/pointer/form/board | Semua jalur yang dicoba dieksekusi tanpa exception browser yang tidak tertangani | PASSED |
| F-07 | RPS completion | Mainkan 5 ronde | Status akhir muncul dan skor per-game masuk ke state lokal | PASSED |
| F-08 | Quick Math completion | Jawab 10 soal berdasarkan soal yang ditampilkan | Status 10/10 benar; skor tersimpan 1000 | PASSED |
| F-09 | Reaction completion | Mulai, tunggu panel hijau, klik | Waktu reaksi dan skor disimpan | PASSED |
| F-10 | Escape close | Tutup sesi aktif memakai Escape | Modal tertutup | PASSED |
| F-11 | Console/runtime errors | Pantau pageerror dan console error selama sweep | 0 page error dan 0 console error pada harness inline | PASSED dalam ruang lingkup harness |
| F-12 | Viewport overflow | Ukur document/body scrollWidth setelah settle | Tidak ada horizontal overflow pada viewport yang terdaftar di atas | PASSED dalam ruang lingkup harness |
| F-13 | Reduced motion visual | Inspeksi kode CSS/media query dan toggle | Kode mengimplementasikan preferensi sistem serta toggle; belum diuji lewat browser preference matrix terpisah | PARTIAL |
| F-14 | Storage refresh persistence | Reload origin web nyata setelah simpan state | Harness menguji state update/score save, bukan reload origin server nyata | NOT TESTED |

## 4. Static and deployment checks

| ID | Tes | Hasil | Status |
|---|---|---|---|
| S-01 | `node --check app.js` | Tidak menemukan syntax error | PASSED |
| S-02 | `node --check service-worker.js` | Tidak menemukan syntax error | PASSED |
| S-03 | File/path inventory | Semua file dalam struktur paket tersedia secara lokal | PASSED |
| S-04 | HTTP response lokal via `curl` | `index.html`, `styles.css`, `app.js`, `service-worker.js`, `manifest.webmanifest`, `assets/icon.svg`, `README.md`, `IMPLEMENTATION-AUDIT.md`, dan `QA-REPORT.md` masing-masing merespons HTTP 200 dari server lokal | PASSED |
| S-05 | Service worker install/activate dan cache hit dari browser | Browser tidak dapat menavigasi ke origin lokal dalam environment ini | BLOCKED |
| S-06 | Deployment aktual ke `htdocs` | Tidak dilakukan | NOT TESTED |

## 5. Performa, visual, aksesibilitas, dan keamanan

| Area | Bukti sekarang | Status |
|---|---|---|
| Ukuran/kode | Tidak ada dependency eksternal; tidak ada gambar/font/video remote; seluruh game logic ada di satu `app.js` | IMPLEMENTED, belum ada pengukuran bandwidth/parsing formal |
| Core Web Vitals | Tidak ada Lighthouse/field data yang dijalankan | NOT TESTED |
| Frame rate / dropped frame | Source menggunakan `requestAnimationFrame` pada game canvas, delta cap, dan lifecycle visibility; tidak ada profiling frame aktual | IMPLEMENTED, NOT MEASURED |
| CPU/GPU/RAM/suhu | Tidak dikumpulkan | NOT TESTED |
| Akses keyboard | Escape close, shortcut `/`, kontrol panah/WASD, tombol native pada banyak board diuji dasar | PARTIAL; perlu matriks keyboard menyeluruh dan screen-reader manual |
| Color contrast | Palet dipilih secara eksplisit, tetapi belum melalui pengukuran WCAG formal untuk semua state | NOT TESTED |
| Responsive | Tidak ada overflow pada 8 viewport dalam harness | PASSED dalam viewport yang diuji; belum membuktikan semua perangkat/orientasi |
| XSS/input | Input game ditampilkan sebagai teks atau diproses angka; tidak ada `eval`/`new Function` dalam aplikasi; tidak ada backend | Inspeksi source saja; bukan audit penetration test |
| Third-party requests | Kode aplikasi tidak memuat CDN, analytics, external fonts, embeds, atau remote game APIs | SOURCE INSPECTION PASSED; network HAR pada origin nyata belum dibuat |
| PWA offline | Service-worker script ada, sintaks valid, precache daftar aset lokal | NOT TESTED pada secure origin nyata |

## 6. Keterbatasan bukti

1. Harness inline memastikan fungsi JavaScript dan beberapa interaksi bekerja, tetapi ia melewati pemuatan file CSS/JS dari server web normal. Karena itu hasil tersebut tidak membuktikan konfigurasi MIME, path subfolder, service worker, atau HTTPS hosting.
2. PWA offline wajib diuji setelah pertama kali membuka situs lewat HTTPS, menunggu service worker aktif, kemudian reload dalam keadaan offline. Uji ini belum berhasil dilakukan di sesi ini.
3. Semua 18 game sudah diuji untuk mount dan satu atau beberapa interaksi dasar; tidak semua game telah dipaksa hingga kondisi menang/kalah seluruhnya.
4. Tidak ada hasil numerik Lighthouse, LCP/INP/CLS lapangan, CPU/GPU, baterai, suhu, atau FPS. Tidak boleh disebut “sangat ringan pada semua perangkat” sebagai hasil terukur.
5. Deployment ke akun InfinityFree belum dilakukan; kemungkinan aturan host, sertifikat/domain, cache browser, atau kebijakan file perlu divalidasi setelah upload.

## 7. Checklist rilis yang disarankan

- [x] 18 game telah diimplementasikan dalam kode.
- [x] Pencarian/kategori/favorit dan state lokal dasar teruji pada harness.
- [x] Syntax JavaScript aplikasi dan worker valid.
- [x] Tidak ada horizontal overflow yang teramati pada delapan lebar viewport harness.
- [ ] Uji langsung semua 18 game di browser produksi setelah deploy.
- [ ] Verifikasi worker `activated` dan kontrol halaman setelah reload kedua.
- [ ] Putuskan jaringan dan reload untuk membuktikan offline launch + offline gameplay.
- [ ] Uji minimal Chrome Android, Firefox desktop, Safari/iOS atau alternatif relevan.
- [ ] Jalankan Lighthouse/DevTools dengan kondisi yang dicatat.
- [ ] Lakukan pemeriksaan keyboard/focus/screen-reader dan contrast yang lebih formal.
- [ ] Simpan bukti hasil dan perbarui status acceptance criteria setelah tes.

**Kesimpulan QA:** `PARTIALLY VERIFIED`. Fitur inti dan 18 mount game telah melewati smoke test berbasis browser inline. Service worker, offline reload pada origin HTTPS, dan deployment InfinityFree masih merupakan kriteria rilis yang belum terverifikasi.
