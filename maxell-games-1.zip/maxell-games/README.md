# MAXELL GAMES — Local Arcade

**Build:** 1.0.0 · **Tipe:** static web app / local-first mini-game arcade · **Dependensi eksternal:** tidak ada.

Maxell Games adalah katalog mini-game dengan art direction cyberpunk. Semua game diproses di browser. Tidak ada login, backend game, database jarak jauh, API skor, font CDN, gambar eksternal, analytics, ataupun iklan.

## Isi paket

```text
maxell-games/
├── index.html                # Markup dan metadata aplikasi
├── styles.css                # Desain cyberpunk, responsivitas, reduced motion
├── app.js                    # Katalog, state lokal, 18 implementasi mini-game
├── service-worker.js         # Precache shell dan fallback navigasi offline
├── manifest.webmanifest      # Metadata PWA/install
├── assets/
│   └── icon.svg              # Ikon vektor lokal
├── README.md                 # Cara menjalankan dan deployment
├── IMPLEMENTATION-AUDIT.md   # Matriks forensik 34 rendering + 33 visual techniques
└── QA-REPORT.md              # Pemeriksaan yang dilakukan dan yang belum diverifikasi
```

## 18 mini-game yang tersedia

| # | Game | Genre | Inti permainan |
|---:|---|---|---|
| 1 | Neon Snake | Arcade | Mengumpulkan energi dan menghindari tabrakan |
| 2 | Cyber Pong | Arcade | Duel paddle melawan CPU sampai lima poin |
| 3 | Neon Breakout | Arcade | Memantulkan bola untuk menghancurkan blok |
| 4 | Void Defender | Arcade | Menggerakkan kapal dan menembak armada drone |
| 5 | 2048: Afterglow | Puzzle | Menggabungkan ubin hingga 2048 |
| 6 | Memory Matrix | Puzzle | Menemukan delapan pasangan kartu |
| 7 | Mine Protocol | Puzzle | Membuka sel aman dan menandai ranjau |
| 8 | Lights Out | Puzzle | Mematikan semua lampu dengan perubahan tetangga |
| 9 | Gridlock: XO | Strategi | Tic-tac-toe melawan CPU minimax |
| 10 | Four in a Row | Strategi | Connect Four melawan CPU heuristik |
| 11 | Rock / Paper / Scissors | Casual | Lima ronde melawan pilihan CPU |
| 12 | Number Decoder | Casual | Menebak angka rahasia 1–100 |
| 13 | Reflex Overdrive | Refleks | Mengukur reaksi setelah sinyal hijau |
| 14 | Signal Sequence | Refleks | Mengingat dan mengulang urutan warna |
| 15 | Quick Math: 10X | Refleks | Sepuluh soal aritmetika |
| 16 | Glitch Hunter | Arcade | Menangkap glitch selama 30 detik |
| 17 | Word Scrambler | Puzzle | Menyusun kata bertema teknologi |
| 18 | Color Override | Refleks | Mencocokkan warna tinta, bukan arti kata |

## Menjalankan secara lokal

1. Ekstrak arsip ZIP ke folder biasa.
2. Buka `index.html` langsung di browser modern. Mini-game tetap berjalan karena kode dan asetnya lokal.
3. Alternatif untuk pengujian yang lebih menyerupai hosting, jalankan server lokal dari direktori proyek:

   ```bash
   python -m http.server 8000
   ```

   Buka `http://localhost:8000`.

**Catatan:** membuka `index.html` melalui `file://` dapat menjalankan gameplay dan penyimpanan lokal yang diizinkan browser, tetapi mode PWA/service worker tidak dijamin tersedia. Untuk menguji cache offline, jalankan lewat `localhost` atau hosting HTTPS.

## Upload ke InfinityFree

1. Unduh dan ekstrak `maxell-games.zip` di perangkat. Jangan upload folder pembungkus ZIP sebagai satu-satunya isi situs.
2. Masuk ke Client Area InfinityFree dan buka File Manager atau koneksi FTP akun.
3. Buka direktori web root **`htdocs`** (atau `domain-anda/htdocs` untuk domain tambahan).
4. Unggah **isi folder** `maxell-games/` ke root `htdocs`, sehingga `index.html` berada langsung di `htdocs/index.html`.
5. Pertahankan struktur `assets/` dan seluruh nama file. Jangan mengubah kapitalisasi nama file.
6. Buka alamat situs melalui HTTPS, muat sekali sampai selesai, lalu buka kembali. Service worker perlu berhasil didaftarkan dan shell aplikasi masuk cache.
7. Untuk pemeriksaan offline: setelah kunjungan online berhasil, aktifkan mode pesawat atau DevTools > Network > Offline, lalu reload. Uji beberapa game. Browser dapat menghapus cache karena tekanan penyimpanan; mode offline bukan jaminan penyimpanan permanen.

Untuk subdomain gratis InfinityFree, dokumentasi komunitasnya menyebut subdomain tersebut disediakan dengan sertifikat SSL sistem sehingga HTTPS umumnya dapat dipakai tanpa memasang sertifikat khusus; verifikasi URL aktual milik akun Anda. File website diunggah ke `htdocs`, bukan ke direktori akun di luarnya.

## Cara bermain dan data lokal

- Pilih kartu game lalu kontrol akan muncul di dalam dialog permainan.
- Tombol `/` memfokuskan pencarian; `Esc` menutup sesi.
- Favorit, jumlah sesi, game terakhir, dan skor terbaik disimpan di `localStorage` browser.
- Tombol `RESET RECORD` menghapus statistik dan favorit lokal setelah konfirmasi. Aksi ini tidak dapat membatalkan data yang sudah dihapus.
- Simpanan browser terpisah antar-browser, antar-profil, dan antar-origin. Data tidak disinkronkan ke perangkat lain.
- Tombol `Kurangi animasi` mengaktifkan mode gerakan rendah. Preferensi `prefers-reduced-motion` sistem juga dihormati.

## Teknologi dan keputusan arsitektur

- HTML semantik, CSS, dan JavaScript native; tidak membutuhkan build step, npm, PHP, MySQL, maupun API.
- Canvas 2D hanya dipakai pada empat game arcade; ukuran internal canvas dibatasi untuk menjaga beban raster yang wajar.
- Mini-game di-mount saat sesi dibuka; requestAnimationFrame pada game canvas dihentikan saat sesi selesai/halaman tidak terlihat, lalu dibersihkan ketika modal ditutup.
- Tidak ada permintaan jaringan runtime di kode aplikasi; service worker hanya menangani aset same-origin.
- Service worker men-cache shell aplikasi. Skor dan favorit memakai `localStorage`, berbeda dari cache aset PWA.

## Batasan yang diketahui

- Tidak ada akun, leaderboard daring, multiplayer, sinkronisasi cloud, back-end, atau penyimpanan lintas perangkat.
- Service worker/PWA tergantung pada HTTPS atau lingkungan localhost dan dukungan browser; kunjungan pertama tetap memerlukan jaringan saat di-host.
- Skor dari genre yang berbeda tidak dapat dibandingkan secara kompetitif; tiap game punya rumus skor internal.
- Beberapa game memakai emoji/simbol teks yang tampilan glyph-nya tergantung font perangkat.
- FPS, suhu perangkat, pemakaian GPU/RAM, Core Web Vitals, dan dukungan lintas-perangkat belum diklaim tanpa pengukuran nyata.

## Struktur penyimpanan

State tersimpan di satu key browser: `maxell-games-state-v1`. Tidak ada data pribadi yang diminta. Jangan menganggap `localStorage` sebagai sistem penyimpanan yang tahan terhadap pembersihan browser atau manipulasi pengguna.


## Referensi deployment dan offline

- InfinityFree — [Cara upload menggunakan FTP](https://forum.infinityfree.com/t/how-to-upload-files-with-ftp/49306)
- InfinityFree — [Panduan HTTPS/SSL untuk hosting gratis](https://forum.infinityfree.com/t/how-to-get-free-ssl-https-on-infinityfree/49323)
- MDN — [Offline and background operation for PWAs](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Offline_and_background_operation)
- MDN — [Secure contexts dan service worker](https://developer.mozilla.org/en-US/docs/Web/Security/Defenses/Secure_Contexts)
