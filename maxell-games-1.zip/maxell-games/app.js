/* Maxell Games — dependency-free, local-first browser arcade. */
(() => {
  'use strict';

  const STORAGE_KEY = 'maxell-games-state-v1';
  const games = [
    { id:'snake', name:'Neon Snake', category:'arcade', difficulty:'EASY', time:'2–5 MIN', description:'Makan energi neon, tumbuh panjang, jangan menabrak diri sendiri.', glyph:'蛇', accent:'#49f7e2', code:'ARCADE / 01', controls:'Panah / WASD atau tombol arah.' },
    { id:'pong', name:'Cyber Pong', category:'arcade', difficulty:'MEDIUM', time:'2–4 MIN', description:'Pertahankan garis pertahanan dan kalahkan CPU dalam duel pantulan.', glyph:'◒', accent:'#ff426f', code:'ARCADE / 02', controls:'W/S atau panah atas-bawah; sentuh area paddle.' },
    { id:'breakout', name:'Neon Breakout', category:'arcade', difficulty:'MEDIUM', time:'3–6 MIN', description:'Hancurkan blok, kendalikan pantulan, dan jangan kehilangan bola.', glyph:'▤', accent:'#d5ff5b', code:'ARCADE / 03', controls:'Gerakkan paddle dengan mouse, sentuhan, atau panah.' },
    { id:'space', name:'Void Defender', category:'arcade', difficulty:'MEDIUM', time:'2–5 MIN', description:'Bersihkan armada drone sebelum barisan musuh mencapai bawah.', glyph:'✦', accent:'#a88bff', code:'ARCADE / 04', controls:'A/D atau panah untuk bergerak, spasi untuk menembak.' },
    { id:'2048', name:'2048: Afterglow', category:'puzzle', difficulty:'MEDIUM', time:'3–8 MIN', description:'Gabungkan ubin dengan nilai sama sampai mencapai angka 2048.', glyph:'2048', accent:'#49f7e2', code:'PUZZLE / 01', controls:'Panah keyboard atau geser papan di layar sentuh.' },
    { id:'memory', name:'Memory Matrix', category:'puzzle', difficulty:'EASY', time:'2–4 MIN', description:'Temukan semua pasangan simbol dengan jumlah langkah sesedikit mungkin.', glyph:'◈', accent:'#ff426f', code:'PUZZLE / 02', controls:'Ketuk atau klik dua kartu untuk mencocokkan simbol.' },
    { id:'mines', name:'Mine Protocol', category:'puzzle', difficulty:'MEDIUM', time:'3–7 MIN', description:'Buka semua sel aman, baca angka petunjuk, tandai ranjau.', glyph:'✹', accent:'#d5ff5b', code:'PUZZLE / 03', controls:'Klik untuk membuka; klik kanan atau tombol bendera untuk menandai.' },
    { id:'lights', name:'Lights Out', category:'puzzle', difficulty:'MEDIUM', time:'2–5 MIN', description:'Matikan seluruh lampu. Setiap pilihan juga mengubah tetangganya.', glyph:'▦', accent:'#49f7e2', code:'PUZZLE / 04', controls:'Klik sel; sel itu dan tetangga ortogonalnya akan berubah.' },
    { id:'tictactoe', name:'Gridlock: XO', category:'strategy', difficulty:'EASY', time:'1–3 MIN', description:'Menangkan tiga simbol berurutan melawan lawan berbasis minimax.', glyph:'X/O', accent:'#a88bff', code:'STRATEGY / 01', controls:'Kamu X, CPU O. Pilih sel kosong.' },
    { id:'connect4', name:'Four in a Row', category:'strategy', difficulty:'MEDIUM', time:'2–5 MIN', description:'Susun empat chip berurutan secara horizontal, vertikal, atau diagonal.', glyph:'●●', accent:'#ff426f', code:'STRATEGY / 02', controls:'Pilih kolom. Kamu magenta, CPU cyan.' },
    { id:'rps', name:'Rock / Paper / Scissors', category:'casual', difficulty:'EASY', time:'1–2 MIN', description:'Pertarungan lima ronde. Kalahkan pilihan CPU dan kumpulkan poin.', glyph:'✊', accent:'#49f7e2', code:'CASUAL / 01', controls:'Pilih batu, kertas, atau gunting pada setiap ronde.' },
    { id:'number', name:'Number Decoder', category:'casual', difficulty:'EASY', time:'1–3 MIN', description:'Temukan angka rahasia 1–100 dengan petunjuk lebih tinggi atau rendah.', glyph:'?01', accent:'#d5ff5b', code:'CASUAL / 02', controls:'Masukkan angka bulat 1 sampai 100.' },
    { id:'reaction', name:'Reflex Overdrive', category:'reaction', difficulty:'EASY', time:'1 MIN', description:'Uji waktu reaksi. Jangan tekan sebelum sinyal berubah hijau.', glyph:'⚡', accent:'#d5ff5b', code:'REFLEX / 01', controls:'Mulai, tunggu hijau, lalu tekan area secepat mungkin.' },
    { id:'simon', name:'Signal Sequence', category:'reaction', difficulty:'MEDIUM', time:'2–5 MIN', description:'Ingat urutan sinyal yang makin panjang dan ulangi dengan benar.', glyph:'◉', accent:'#a88bff', code:'REFLEX / 02', controls:'Perhatikan urutan cahaya, kemudian tekan warna dengan urutan sama.' },
    { id:'math', name:'Quick Math: 10X', category:'reaction', difficulty:'EASY', time:'1–3 MIN', description:'Selesaikan sepuluh soal aritmetika cepat. Setiap jawaban benar bernilai 100.', glyph:'∑', accent:'#49f7e2', code:'REFLEX / 03', controls:'Ketik jawaban angka dan tekan Enter atau tombol kirim.' },
    { id:'whack', name:'Glitch Hunter', category:'arcade', difficulty:'EASY', time:'30 SEC', description:'Tangkap glitch yang muncul acak sebelum sesi 30 detik berakhir.', glyph:'⌖', accent:'#ff426f', code:'ARCADE / 05', controls:'Ketuk simbol yang menyala; jangan buang waktu pada sel kosong.' },
    { id:'word', name:'Word Scrambler', category:'puzzle', difficulty:'EASY', time:'2–4 MIN', description:'Susun kembali huruf acak menjadi kata bertema teknologi dan arcade.', glyph:'Aa', accent:'#a88bff', code:'PUZZLE / 05', controls:'Susun huruf, lalu masukkan kata dan tekan Enter.' },
    { id:'color', name:'Color Override', category:'reaction', difficulty:'MEDIUM', time:'30 SEC', description:'Abaikan arti teks. Pilih nama warna yang sesuai dengan warna tinta.', glyph:'RGB', accent:'#ff426f', code:'REFLEX / 04', controls:'Cocokkan warna tinta, bukan kata yang sedang tertulis.' }
  ];
  const categoryNames = { all:'Semua game', arcade:'Arcade', puzzle:'Puzzle', strategy:'Strategi', reaction:'Refleks', casual:'Casual' };
  const $ = (selector, root=document) => root.querySelector(selector);
  const $$ = (selector, root=document) => Array.from(root.querySelectorAll(selector));
  const grid = $('#game-grid');
  const overlay = $('#game-overlay');
  const stage = $('#game-stage');
  const modalTitle = $('#modal-title');
  const modalDescription = $('#modal-description');
  const modalBest = $('#modal-best');
  const connectionLabel = $('#connection-label');
  let currentCategory = 'all';
  let favoritesOnly = false;
  let currentGame = null;
  let currentCleanup = null;
  let currentAbort = null;
  let lastFocused = null;
  let deferredInstallPrompt = null;

  const defaultState = () => ({ played:0, favorites:[], scores:{}, lastPlayed:null, lastScore:null, lastGameName:null, recent:[] });
  function loadState() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (!parsed || typeof parsed !== 'object') return defaultState();
      return { ...defaultState(), ...parsed, favorites:Array.isArray(parsed.favorites)?parsed.favorites:[], scores:parsed.scores && typeof parsed.scores==='object'?parsed.scores:{}, recent:Array.isArray(parsed.recent)?parsed.recent:[] };
    } catch (_) { return defaultState(); }
  }
  let state = loadState();
  function saveState() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) { toast('Penyimpanan lokal tidak tersedia; sesi ini tidak akan tersimpan.', true); } }
  function escapeHTML(value) { return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
  function formatScore(score) { return Number.isFinite(score) ? Math.round(score).toLocaleString('id-ID') : '—'; }
  function toast(message, error=false) {
    const node = document.createElement('div'); node.className = `toast${error?' error':''}`; node.textContent = message; $('#toast-region').append(node);
    window.setTimeout(() => node.remove(), 3300);
  }
  function cardMarkup(game, index) {
    const favorite = state.favorites.includes(game.id);
    const recent = state.recent[0] === game.id;
    const glyphClass = game.glyph.length > 3 || /[A-Za-z0-9]/.test(game.glyph) && game.glyph.length >= 3 ? 'game-art-glyph text-glyph' : 'game-art-glyph';
    return `<article class="game-card" data-game="${game.id}" data-recent="${recent?'true':'false'}" style="--accent:${game.accent}">
      <div class="card-top"><span class="card-index">MX-${String(index+1).padStart(2,'0')}</span><span class="card-category">${escapeHTML(categoryNames[game.category])}</span></div>
      <button class="favorite-button" type="button" data-favorite="${game.id}" aria-pressed="${favorite}" aria-label="${favorite?'Hapus dari':'Tambah ke'} favorit: ${escapeHTML(game.name)}" title="Favorit">${favorite?'★':'☆'}</button>
      <div class="game-art" aria-hidden="true"><span class="${glyphClass}">${escapeHTML(game.glyph)}</span><span class="game-art-stamp">${escapeHTML(game.code)}</span></div>
      <div class="card-content"><h3>${escapeHTML(game.name)}</h3><p>${escapeHTML(game.description)}</p><div class="card-meta"><span class="difficulty"><i></i>${escapeHTML(game.difficulty)} <span aria-hidden="true">·</span> ${escapeHTML(game.time)}</span><button class="play-card-button" type="button" data-play="${game.id}" aria-label="Mainkan ${escapeHTML(game.name)}" title="Mainkan">↗</button></div></div>
    </article>`;
  }
  function renderLibrary() {
    const query = $('#game-search').value.trim().toLowerCase();
    const visible = games.filter(game => {
      const categoryOK = currentCategory==='all' || game.category===currentCategory;
      const favoriteOK = !favoritesOnly || state.favorites.includes(game.id);
      const queryOK = !query || [game.name,game.description,game.category,game.difficulty,game.controls].join(' ').toLowerCase().includes(query);
      return categoryOK && favoriteOK && queryOK;
    });
    grid.innerHTML = visible.map(game => cardMarkup(game, games.findIndex(item=>item.id===game.id))).join('');
    grid.setAttribute('aria-busy','false');
    $('#game-count').textContent = String(games.length);
    $('#played-count').textContent = formatScore(state.played);
    $('#favorite-count').textContent = String(state.favorites.length);
    $('#results-label').textContent = `${visible.length} GAME${visible.length===1?'':'S'} ${visible.length===1?'TERSEDIA':'TERSEDIA'}`;
    $('#empty-state').hidden = visible.length !== 0;
    $$('.category-chip').forEach(button => { const active = button.dataset.category===currentCategory; button.classList.toggle('active',active); button.setAttribute('aria-pressed',String(active)); });
    $('#favorites-filter').setAttribute('aria-pressed',String(favoritesOnly));
    const bestEntry = Object.entries(state.scores).sort((a,b)=>(Number(b[1]?.score)||0)-(Number(a[1]?.score)||0))[0];
    $('#best-score').textContent = bestEntry ? formatScore(bestEntry[1].score) : '—';
    $('#last-played').textContent = state.lastGameName || '—';
    $('#activity-headline').textContent = state.lastGameName ? `Sesi terakhir: ${state.lastGameName}` : 'Belum ada sesi tercatat';
    $('#activity-description').textContent = state.lastScore!==null && state.lastScore!==undefined ? `Skor terakhir tersimpan: ${formatScore(state.lastScore)}. Rekor disimpan di perangkat ini.` : 'Pilih mini-game untuk mulai membuat rekam permainan lokal.';
    if (currentGame) modalBest.textContent = `BEST: ${state.scores[currentGame]?.score!==undefined?formatScore(state.scores[currentGame].score):'—'}`;
  }
  function toggleFavorite(id) {
    if (state.favorites.includes(id)) state.favorites = state.favorites.filter(item=>item!==id); else state.favorites.push(id);
    saveState(); renderLibrary(); toast(state.favorites.includes(id)?'Game ditambahkan ke favorit.':'Game dihapus dari favorit.');
  }
  function recordPlay(id) {
    const game = games.find(item=>item.id===id); if (!game) return;
    state.played += 1; state.lastPlayed = id; state.lastGameName = game.name; state.lastScore = null;
    state.recent = [id,...state.recent.filter(item=>item!==id)].slice(0,5); saveState(); renderLibrary();
  }
  function recordScore(id, score, note='Sesi selesai.') {
    if (!Number.isFinite(score)) return;
    const game = games.find(item=>item.id===id); if (!game) return;
    const rounded = Math.max(0,Math.round(score)); const previous = state.scores[id];
    if (!previous || rounded > Number(previous.score)) state.scores[id] = { score:rounded, date:new Date().toISOString() };
    state.lastPlayed = id; state.lastGameName = game.name; state.lastScore = rounded;
    saveState(); renderLibrary();
    if (currentGame===id) modalBest.textContent = `BEST: ${formatScore(state.scores[id]?.score)}`;
    toast(`${note} Skor: ${formatScore(rounded)}.`);
  }
  function openGame(id, trigger) {
    const game = games.find(item=>item.id===id); if (!game) return;
    closeGame(false);
    lastFocused = trigger || document.activeElement;
    currentGame = id; currentAbort = new AbortController();
    const signal = currentAbort.signal;
    modalTitle.textContent = game.name.toUpperCase(); modalDescription.textContent = `${game.description} Kontrol: ${game.controls}`;
    modalBest.textContent = `BEST: ${state.scores[id]?.score!==undefined?formatScore(state.scores[id].score):'—'}`;
    stage.innerHTML = ''; overlay.hidden = false; document.body.style.overflow = 'hidden';
    recordPlay(id);
    try {
      currentCleanup = mountGame(id, stage, {
        signal,
        done:(score,note)=>recordScore(id,score,note),
        toast,
        getBest:()=>state.scores[id]?.score ?? null
      });
    } catch (error) {
      console.error('Game mount failed:', id, error);
      stage.innerHTML = `<div class="empty-state"><h3>SESSION INTERRUPTED</h3><p>Game gagal dimulai. Tutup sesi dan coba kembali.</p><button class="game-btn" id="retry-game" type="button">COBA LAGI</button></div>`;
      $('#retry-game',stage).addEventListener('click',()=>openGame(id,lastFocused),{signal});
      toast('Game gagal dimulai. Detail tersedia di konsol browser.',true);
    }
    $('#close-game').focus();
  }
  function closeGame(restoreFocus=true) {
    if (currentAbort) currentAbort.abort();
    if (typeof currentCleanup==='function') { try { currentCleanup(); } catch (error) { console.warn('Game cleanup issue:',error); } }
    currentCleanup = null; currentAbort = null; currentGame = null;
    stage.innerHTML = ''; overlay.hidden = true; document.body.style.overflow = '';
    if (restoreFocus && lastFocused && typeof lastFocused.focus==='function') lastFocused.focus();
  }
  function panel(root, {toolbar='',content='',controls='',help='',status='Siap dimainkan.'}={}) {
    root.innerHTML = `<div class="game-panel"><div class="game-toolbar">${toolbar}</div>${content}${controls?`<div class="game-controls">${controls}</div>`:''}<p class="game-status" aria-live="polite">${status}</p>${help?`<p class="game-help">${help}</p>`:''}</div>`;
    return { panel:$('.game-panel',root), status:$('.game-status',root) };
  }
  const stat = (label,value,id='') => `<span class="game-stat">${label} <strong${id?` id="${id}"`:''}>${value}</strong></span>`;
  const btn = (label,id,secondary=false) => `<button class="game-btn${secondary?' secondary':''}" type="button" id="${id}">${label}</button>`;
  function signalButton(id, fn, signal) { const element = document.getElementById(id); if (element) element.addEventListener('click',fn,{signal}); return element; }
  function randomInt(max) { return Math.floor(Math.random()*max); }
  function shuffle(arr) { for(let i=arr.length-1;i>0;i--){const j=randomInt(i+1);[arr[i],arr[j]]=[arr[j],arr[i]];} return arr; }
  function rafLoop(draw, signal) {
    let frame=0,last=0,active=false;
    const stop=()=>{active=false;cancelAnimationFrame(frame);};
    const start=()=>{if(active||signal.aborted||document.hidden)return;active=true;last=0;frame=requestAnimationFrame(loop);};
    const loop = now => { if (!active || signal.aborted) return; const dt=last?Math.min(50,now-last):16; last=now; if (!document.hidden && draw(dt,now)===false){stop();return;} frame=requestAnimationFrame(loop); };
    stop.resume=start;start();signal.addEventListener('abort',stop,{once:true});
    const visibility=()=>{if(document.hidden)stop();else start();};
    document.addEventListener('visibilitychange',visibility,{signal});
    return stop;
  }
  function mountGame(id, root, ctx) {
    switch(id) {
      case 'snake': return mountSnake(root,ctx);
      case 'pong': return mountPong(root,ctx);
      case 'breakout': return mountBreakout(root,ctx);
      case 'space': return mountSpace(root,ctx);
      case '2048': return mount2048(root,ctx);
      case 'memory': return mountMemory(root,ctx);
      case 'mines': return mountMines(root,ctx);
      case 'lights': return mountLights(root,ctx);
      case 'tictactoe': return mountTicTacToe(root,ctx);
      case 'connect4': return mountConnect4(root,ctx);
      case 'rps': return mountRPS(root,ctx);
      case 'number': return mountNumber(root,ctx);
      case 'reaction': return mountReaction(root,ctx);
      case 'simon': return mountSimon(root,ctx);
      case 'math': return mountMath(root,ctx);
      case 'whack': return mountWhack(root,ctx);
      case 'word': return mountWord(root,ctx);
      case 'color': return mountColor(root,ctx);
      default: throw new Error('Unknown game id');
    }
  }

  function mountSnake(root,ctx) {
    const ui=panel(root,{toolbar:stat('SCORE','0','snake-score')+stat('BEST',formatScore(ctx.getBest()??0))+stat('GRID','24 × 16'),content:'<canvas class="game-canvas" width="480" height="320" aria-label="Arena Snake"></canvas>',controls:'<button class="game-btn secondary" data-dir="up" type="button">↑</button><button class="game-btn secondary" data-dir="left" type="button">←</button><button class="game-btn secondary" data-dir="down" type="button">↓</button><button class="game-btn secondary" data-dir="right" type="button">→</button>'+btn('RESTART','snake-restart'),help:'Gunakan panah/WASD atau tombol arah. Area permainan menyesuaikan lebar layar.'});
    const canvas=$('canvas',root),c=canvas.getContext('2d'); const W=480,H=320,cols=24,rows=16,cell=20; let snake,dir,next,food,score,acc=0,over=false,started=false; let stop=()=>{};
    function reset(){stop.resume?.();snake=[{x:8,y:8},{x:7,y:8},{x:6,y:8}];dir={x:1,y:0};next={...dir};food=placeFood();score=0;acc=0;over=false;started=true;ui.status.textContent='Sinyal aktif. Ambil energi neon.';$('#snake-score',root).textContent='0';draw();}
    function placeFood(){let p;do{p={x:randomInt(cols),y:randomInt(rows)}}while(snake&&snake.some(s=>s.x===p.x&&s.y===p.y));return p;}
    function draw(){c.fillStyle='#080d16';c.fillRect(0,0,W,H);c.strokeStyle='rgba(73,247,226,.055)';c.lineWidth=1;for(let x=0;x<=W;x+=cell){c.beginPath();c.moveTo(x,0);c.lineTo(x,H);c.stroke()}for(let y=0;y<=H;y+=cell){c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke()}if(!snake)return;c.fillStyle='#ff426f';c.shadowColor='#ff426f';c.shadowBlur=12;c.fillRect(food.x*cell+4,food.y*cell+4,cell-8,cell-8);c.shadowBlur=0;snake.forEach((p,i)=>{c.fillStyle=i===0?'#49f7e2':'#167f79';c.shadowColor=i===0?'#49f7e2':'transparent';c.shadowBlur=i===0?9:0;c.fillRect(p.x*cell+2,p.y*cell+2,cell-4,cell-4)});c.shadowBlur=0;if(over){c.fillStyle='rgba(5,8,14,.72)';c.fillRect(0,0,W,H);c.fillStyle='#f4f3ef';c.textAlign='center';c.font='bold 26px monospace';c.fillText('SIGNAL LOST',W/2,H/2-4);c.font='12px monospace';c.fillStyle='#49f7e2';c.fillText(`SCORE ${score}  /  RESTART TO RETRY`,W/2,H/2+22)}}
    function tick(){if(over)return;dir={...next};const head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};const eating=head.x===food.x&&head.y===food.y;const body=eating?snake:snake.slice(0,-1);if(head.x<0||head.y<0||head.x>=cols||head.y>=rows||body.some(p=>p.x===head.x&&p.y===head.y)){over=true;ui.status.textContent=`Game over. Energi terkumpul: ${score}.`;ctx.done(score,'Neon Snake selesai.');draw();return;}snake.unshift(head);if(eating){score+=10;food=placeFood();$('#snake-score',root).textContent=String(score)}else snake.pop();draw();}
    const key=e=>{const map={ArrowUp:{x:0,y:-1},w:{x:0,y:-1},ArrowDown:{x:0,y:1},s:{x:0,y:1},ArrowLeft:{x:-1,y:0},a:{x:-1,y:0},ArrowRight:{x:1,y:0},d:{x:1,y:0}};const nd=map[e.key];if(!nd)return;if(e.target.closest('input,button')){if(e.target.tagName==='INPUT')return;}e.preventDefault();if(nd.x!==-dir.x||nd.y!==-dir.y)next=nd;};document.addEventListener('keydown',key,{signal:ctx.signal});
    root.addEventListener('click',e=>{const b=e.target.closest('[data-dir]');if(!b)return;const map={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}};const nd=map[b.dataset.dir];if(nd.x!==-dir.x||nd.y!==-dir.y)next=nd;},{signal:ctx.signal});signalButton('snake-restart',reset,ctx.signal);reset();stop=rafLoop((dt)=>{if(!started||over)return false;acc+=dt;const step=Math.max(65,130-score*.15);while(acc>=step){tick();acc-=step;if(over)break;}return !over;},ctx.signal);return ()=>stop();
  }

  function mountPong(root,ctx) {
    const ui=panel(root,{toolbar:stat('YOU','0','pong-player-score')+stat('CPU','0','pong-cpu-score')+stat('TARGET','5'),content:'<canvas class="game-canvas" width="500" height="300" aria-label="Arena Pong"></canvas>',controls:btn('RESTART MATCH','pong-restart'),help:'Gerakkan paddle dengan W/S, panah atas-bawah, atau sentuh/seret sisi kiri arena.'});
    const can=$('canvas',root),c=can.getContext('2d'),W=500,H=300;let py=120,ay=120,ball,ps=0,as=0,over=false,stop=()=>{};
    function serve(direction=1){ball={x:W/2,y:H/2,vx:direction*(3.1+Math.random()),vy:(Math.random()-.5)*3.4};}
    function reset(){stop.resume?.();py=ay=120;ps=as=0;over=false;serve(Math.random()>.5?1:-1);ui.status.textContent='First to five. Keep the signal alive.';$('#pong-player-score',root).textContent='0';$('#pong-cpu-score',root).textContent='0';draw();}
    function draw(){c.fillStyle='#080d16';c.fillRect(0,0,W,H);c.setLineDash([5,8]);c.strokeStyle='rgba(73,247,226,.22)';c.beginPath();c.moveTo(W/2,0);c.lineTo(W/2,H);c.stroke();c.setLineDash([]);c.fillStyle='#49f7e2';c.shadowColor='#49f7e2';c.shadowBlur=9;c.fillRect(20,py,9,60);c.fillStyle='#ff426f';c.shadowColor='#ff426f';c.fillRect(W-29,ay,9,60);c.fillStyle='#f4f3ef';c.shadowBlur=12;c.beginPath();c.arc(ball.x,ball.y,6,0,Math.PI*2);c.fill();c.shadowBlur=0;if(over){c.fillStyle='rgba(5,8,14,.72)';c.fillRect(0,0,W,H);c.fillStyle='#f4f3ef';c.textAlign='center';c.font='bold 24px monospace';c.fillText(ps>=5?'PLAYER WINS':'CPU WINS',W/2,H/2);}}
    function point(player){if(player){ps++;$('#pong-player-score',root).textContent=ps;}else{as++;$('#pong-cpu-score',root).textContent=as;}if(ps>=5||as>=5){over=true;ui.status.textContent=ps>=5?'Match menang. Nice rally.':'CPU menang. Coba lagi untuk rematch.';ctx.done(ps*100,'Cyber Pong selesai.');}else serve(player?-1:1);draw();}
    function drawTick(dt){if(over)return false;const f=dt/16.7;ball.x+=ball.vx*f;ball.y+=ball.vy*f;if(ball.y<7||ball.y>H-7)ball.vy*=-1;ay+=((ball.y-30)-ay)*Math.min(.08,.035*f);ay=Math.max(0,Math.min(H-60,ay));if(ball.x<31&&ball.x>19&&ball.y>=py-5&&ball.y<=py+65){ball.vx=Math.abs(ball.vx)*1.045;ball.vy+=((ball.y-(py+30))/30)*1.1;ball.x=31;}if(ball.x>W-31&&ball.x<W-19&&ball.y>=ay-5&&ball.y<=ay+65){ball.vx=-Math.abs(ball.vx)*1.045;ball.vy+=((ball.y-(ay+30))/30)*.8;ball.x=W-31;}if(ball.x<0)point(false);if(ball.x>W)point(true);draw();return !over;}
    const move=e=>{if(e.key==='ArrowUp'||e.key.toLowerCase()==='w'){e.preventDefault();py=Math.max(0,py-18)}else if(e.key==='ArrowDown'||e.key.toLowerCase()==='s'){e.preventDefault();py=Math.min(H-60,py+18)}};document.addEventListener('keydown',move,{signal:ctx.signal});const pointer=e=>{const r=can.getBoundingClientRect();py=Math.max(0,Math.min(H-60,((e.clientY-r.top)/r.height)*H-30));};can.addEventListener('pointermove',pointer,{signal:ctx.signal});signalButton('pong-restart',reset,ctx.signal);reset();stop=rafLoop(drawTick,ctx.signal);return ()=>stop();
  }

  function mountBreakout(root,ctx) {
    const ui=panel(root,{toolbar:stat('SCORE','0','breakout-score')+stat('LIVES','3','breakout-lives')+stat('BLOCKS','32','breakout-blocks'),content:'<canvas class="game-canvas" width="480" height="330" aria-label="Arena Breakout"></canvas>',controls:btn('RESTART RUN','breakout-restart'),help:'Gerakkan paddle dengan pointer/sentuhan atau tombol panah kiri-kanan.'});
    const can=$('canvas',root),c=can.getContext('2d'),W=480,H=330;let paddle=200,ball,bricks,score=0,lives=3,over=false,stopLoop=()=>{},keys={left:false,right:false};
    function reset(){stopLoop?.resume?.();paddle=200;ball={x:240,y:276,vx:2.4,vy:-3};bricks=[];for(let r=0;r<4;r++)for(let col=0;col<8;col++)bricks.push({x:18+col*56,y:35+r*22,w:48,h:13,alive:true,color:['#49f7e2','#a88bff','#ff426f','#d5ff5b'][r]});score=0;lives=3;over=false;updateStats();ui.status.textContent='Break all blocks. Keep the ball in play.';draw();}
    function updateStats(){ $('#breakout-score',root).textContent=score;$('#breakout-lives',root).textContent=lives;$('#breakout-blocks',root).textContent=bricks.filter(b=>b.alive).length; }
    function draw(){c.fillStyle='#080d16';c.fillRect(0,0,W,H);bricks.forEach(b=>{if(!b.alive)return;c.fillStyle=b.color;c.shadowColor=b.color;c.shadowBlur=5;c.fillRect(b.x,b.y,b.w,b.h)});c.shadowBlur=0;c.fillStyle='#49f7e2';c.fillRect(paddle,H-22,80,7);c.fillStyle='#f4f3ef';c.shadowColor='#f4f3ef';c.shadowBlur=8;c.beginPath();c.arc(ball.x,ball.y,5,0,Math.PI*2);c.fill();c.shadowBlur=0;if(over){c.fillStyle='rgba(4,7,13,.75)';c.fillRect(0,0,W,H);c.fillStyle='#f4f3ef';c.textAlign='center';c.font='bold 24px monospace';c.fillText(bricks.every(b=>!b.alive)?'BLOCKS CLEARED':'RUN ENDED',W/2,H/2);}}
    function tick(dt){if(over)return false;const f=dt/16.7;if(keys.left)paddle-=5*f;if(keys.right)paddle+=5*f;paddle=Math.max(0,Math.min(W-80,paddle));ball.x+=ball.vx*f;ball.y+=ball.vy*f;if(ball.x<5||ball.x>W-5)ball.vx*=-1;if(ball.y<5)ball.vy=Math.abs(ball.vy);if(ball.y>H-30&&ball.y<H-13&&ball.x>paddle-3&&ball.x<paddle+83){ball.vy=-Math.abs(ball.vy);ball.vx+=((ball.x-(paddle+40))/40)*1.1;ball.y=H-30;}for(const b of bricks){if(!b.alive)continue;if(ball.x>b.x&&ball.x<b.x+b.w&&ball.y>b.y&&ball.y<b.y+b.h){b.alive=false;score+=10;ball.vy*=-1;break;}}if(ball.y>H+8){lives--;if(lives<=0){over=true;ui.status.textContent=`Run selesai dengan ${score} poin.`;ctx.done(score,'Neon Breakout selesai.');}else ball={x:paddle+40,y:H-38,vx:(Math.random()-.5)*4,vy:-3};}if(bricks.every(b=>!b.alive)){over=true;ui.status.textContent='Arena bersih. Semua blok dihancurkan.';ctx.done(score+500,'Neon Breakout menang.');}updateStats();draw();return !over;}
    const keyDown=e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();keys[e.key==='ArrowLeft'?'left':'right']=true;}};const keyUp=e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight')keys[e.key==='ArrowLeft'?'left':'right']=false;};document.addEventListener('keydown',keyDown,{signal:ctx.signal});document.addEventListener('keyup',keyUp,{signal:ctx.signal});can.addEventListener('pointermove',e=>{const r=can.getBoundingClientRect();paddle=((e.clientX-r.left)/r.width)*W-40;},{signal:ctx.signal});signalButton('breakout-restart',reset,ctx.signal);reset();stopLoop=rafLoop(tick,ctx.signal);return ()=>{stopLoop();keys={left:false,right:false};};
  }

  function mountSpace(root,ctx) {
    const ui=panel(root,{toolbar:stat('SCORE','0','space-score')+stat('HULL','3','space-lives')+stat('WAVE','01','space-wave'),content:'<canvas class="game-canvas" width="480" height="340" aria-label="Arena Void Defender"></canvas>',controls:btn('RESTART DEFENSE','space-restart'),help:'A/D atau panah untuk bergerak. Spasi untuk menembak; di ponsel gunakan pointer pada area arena.'});
    const can=$('canvas',root),c=can.getContext('2d'),W=480,H=340;let ship,bullets,enemies,enemyBullets,score,lives,wave,over,shooting=false,keys={left:false,right:false,fire:false},stop=()=>{};
    function reset(){stop.resume?.();ship={x:W/2,y:H-30};bullets=[];enemyBullets=[];score=0;lives=3;wave=1;over=false;keys={left:false,right:false,fire:false};spawnWave();update();ui.status.textContent='Hostile signals detected. Clear the wave.';draw();}
    function spawnWave(){enemies=[];for(let r=0;r<3;r++)for(let col=0;col<8;col++)enemies.push({x:38+col*56,y:36+r*27,w:24,h:15,dir:1});}
    function update(){ $('#space-score',root).textContent=score;$('#space-lives',root).textContent=lives;$('#space-wave',root).textContent=String(wave).padStart(2,'0'); }
    function draw(){c.fillStyle='#070b14';c.fillRect(0,0,W,H);for(let i=0;i<38;i++){const x=(i*79+13)%W,y=(i*43+7)%H;c.fillStyle='rgba(174,191,219,.22)';c.fillRect(x,y,1,1)}c.fillStyle='#49f7e2';c.shadowColor='#49f7e2';c.shadowBlur=10;c.beginPath();c.moveTo(ship.x,ship.y-12);c.lineTo(ship.x-11,ship.y+10);c.lineTo(ship.x+11,ship.y+10);c.closePath();c.fill();c.shadowBlur=0;enemies.forEach(e=>{c.fillStyle='#ff426f';c.fillRect(e.x,e.y,e.w,e.h);c.fillRect(e.x+4,e.y-3,e.w-8,3)});c.fillStyle='#d5ff5b';bullets.forEach(b=>c.fillRect(b.x-2,b.y-7,4,9));c.fillStyle='#a88bff';enemyBullets.forEach(b=>c.fillRect(b.x-2,b.y,4,7));if(over){c.fillStyle='rgba(4,7,13,.8)';c.fillRect(0,0,W,H);c.fillStyle='#f4f3ef';c.textAlign='center';c.font='bold 24px monospace';c.fillText('DEFENSE ENDED',W/2,H/2);}}
    function tick(dt){if(over)return false;const f=dt/16.7;if(keys.left)ship.x-=4.2*f;if(keys.right)ship.x+=4.2*f;ship.x=Math.max(12,Math.min(W-12,ship.x));if(keys.fire&&bullets.length<7){bullets.push({x:ship.x,y:ship.y-13});keys.fire=false;}bullets.forEach(b=>b.y-=6*f);enemyBullets.forEach(b=>b.y+=2.8*f);bullets=bullets.filter(b=>b.y>-8);enemyBullets=enemyBullets.filter(b=>b.y<H+8);const dx=enemies.length?Math.max(...enemies.map(e=>e.x+e.w))>=W-10||Math.min(...enemies.map(e=>e.x))<=10:false;const direction=dx?-1:1;enemies.forEach(e=>{e.x+=direction*.75*f;e.y+=dx?5*f:0;if(Math.random()<.0012*f)enemyBullets.push({x:e.x+e.w/2,y:e.y+e.h});});for(const b of bullets){const hit=enemies.find(e=>b.x>=e.x&&b.x<=e.x+e.w&&b.y>=e.y&&b.y<=e.y+e.h);if(hit){hit.dead=true;b.dead=true;score+=10;}}bullets=bullets.filter(b=>!b.dead);enemies=enemies.filter(e=>!e.dead);for(const b of enemyBullets){if(Math.abs(b.x-ship.x)<12&&Math.abs(b.y-ship.y)<13){b.dead=true;lives--;if(lives<=0){over=true;ui.status.textContent=`Pertahanan berakhir pada wave ${wave}. Skor ${score}.`;ctx.done(score,'Void Defender selesai.');}}}enemyBullets=enemyBullets.filter(b=>!b.dead);if(enemies.some(e=>e.y>H-55)){over=true;lives=0;ui.status.textContent='Drone berhasil menembus garis pertahanan.';ctx.done(score,'Void Defender gagal.');}if(!enemies.length&&!over){wave++;spawnWave();enemyBullets=[];ui.status.textContent=`Wave ${wave} aktif. Tetap bergerak.`;}update();draw();return !over;}
    const keydown=e=>{const key=e.key.toLowerCase();if(['arrowleft','arrowright',' ','a','d'].includes(key)){e.preventDefault();}if(key==='arrowleft'||key==='a')keys.left=true;if(key==='arrowright'||key==='d')keys.right=true;if(key===' ')keys.fire=true;};const keyup=e=>{const k=e.key.toLowerCase();if(k==='arrowleft'||k==='a')keys.left=false;if(k==='arrowright'||k==='d')keys.right=false;if(k===' ')keys.fire=false;};document.addEventListener('keydown',keydown,{signal:ctx.signal});document.addEventListener('keyup',keyup,{signal:ctx.signal});can.addEventListener('pointermove',e=>{const r=can.getBoundingClientRect();ship.x=((e.clientX-r.left)/r.width)*W;},{signal:ctx.signal});can.addEventListener('pointerdown',()=>{keys.fire=true;},{signal:ctx.signal});signalButton('space-restart',reset,ctx.signal);reset();stop=rafLoop(tick,ctx.signal);return ()=>{stop();keys={left:false,right:false,fire:false};};
  }

  function mount2048(root,ctx) {
    const ui=panel(root,{toolbar:stat('SCORE','0','s2048-score')+stat('BEST TILE','0','s2048-tile')+stat('TARGET','2048'),content:'<div class="board grid-2048" id="board-2048" role="group" aria-label="Papan 2048"></div>',controls:btn('NEW BOARD','s2048-reset'),help:'Gunakan tombol panah pada keyboard, atau geser papan ke arah yang diinginkan.'});
    let board,score,won,over,touchStart=null;const el=$('#board-2048',root);
    function reset(){board=Array(16).fill(0);score=0;won=false;over=false;spawn();spawn();draw();ui.status.textContent='Gabungkan angka yang sama. Capai 2048.';}
    function spawn(){const empty=board.map((v,i)=>v===0?i:-1).filter(i=>i>=0);if(empty.length)board[empty[randomInt(empty.length)]]=Math.random()<.9?2:4;}
    function draw(){el.innerHTML=board.map((v,i)=>`<button type="button" data-i="${i}" class="tile-${v}" aria-label="Sel ${i+1}: ${v||'kosong'}" disabled>${v||''}</button>`).join('');$('#s2048-score',root).textContent=score;$('#s2048-tile',root).textContent=Math.max(...board);}
    function move(dir){if(over)return;const before=board.join(',');let next=board.slice();for(let line=0;line<4;line++){let inds=[];for(let pos=0;pos<4;pos++){const r=dir==='up'?pos:dir==='down'?3-pos:line,c=dir==='left'?pos:dir==='right'?3-pos:line;inds.push(r*4+c);}if(dir==='up'||dir==='down'){inds=[];for(let pos=0;pos<4;pos++)inds.push((dir==='up'?pos:3-pos)*4+line);}else{inds=[];for(let pos=0;pos<4;pos++)inds.push(line*4+(dir==='left'?pos:3-pos));}let vals=inds.map(i=>next[i]).filter(v=>v!==0),merged=[];for(let i=0;i<vals.length;i++){if(vals[i]===vals[i+1]){merged.push(vals[i]*2);score+=vals[i]*2;i++;}else merged.push(vals[i]);}while(merged.length<4)merged.push(0);inds.forEach((idx,j)=>next[idx]=merged[j]);}board=next;if(before!==board.join(',')){spawn();draw();}if(Math.max(...board)>=2048&&!won){won=true;ui.status.textContent='Target 2048 tercapai. Kamu bisa tetap bermain.';ctx.done(score+2048,'2048 target tercapai.');}if(!canMove()){over=true;ui.status.textContent=`Tidak ada gerakan tersisa. Skor akhir ${score}.`;ctx.done(score,'2048 selesai.');}}
    function canMove(){if(board.includes(0))return true;for(let r=0;r<4;r++)for(let c=0;c<4;c++){const i=r*4+c;if(c<3&&board[i]===board[i+1]||r<3&&board[i]===board[i+4])return true;}return false;}
    const key=e=>{const map={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right'};if(map[e.key]){e.preventDefault();move(map[e.key]);}};document.addEventListener('keydown',key,{signal:ctx.signal});el.addEventListener('touchstart',e=>{const t=e.changedTouches[0];touchStart={x:t.clientX,y:t.clientY};},{passive:true,signal:ctx.signal});el.addEventListener('touchend',e=>{if(!touchStart)return;const t=e.changedTouches[0],dx=t.clientX-touchStart.x,dy=t.clientY-touchStart.y;touchStart=null;if(Math.max(Math.abs(dx),Math.abs(dy))<25)return;move(Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up'));},{passive:true,signal:ctx.signal});signalButton('s2048-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountMemory(root,ctx) {
    const symbols=['⌘','⌬','◈','⚡','✦','⌖','◉','▣'];let deck,flipped,matches,moves,lock,seconds,timer,flipTimer;
    const ui=panel(root,{toolbar:stat('MATCHED','0/8','memory-matched')+stat('MOVES','0','memory-moves')+stat('TIME','0s','memory-time'),content:'<div class="board memory-board" id="memory-board" role="group" aria-label="Kartu memory"></div>',controls:btn('SHUFFLE CARDS','memory-reset'),help:'Buka dua kartu setiap giliran. Pasangan yang cocok tetap terbuka.'});const el=$('#memory-board',root);
    function reset(){clearInterval(timer);clearTimeout(flipTimer);deck=shuffle([...symbols,...symbols].map((s,i)=>({s,id:i})));flipped=[];matches=[];moves=0;lock=false;seconds=0;draw();$('#memory-matched',root).textContent='0/8';$('#memory-moves',root).textContent='0';$('#memory-time',root).textContent='0s';ui.status.textContent='Cari delapan pasangan.';timer=setInterval(()=>{if(document.hidden)return;seconds++;$('#memory-time',root).textContent=`${seconds}s`;},1000);}
    function draw(){el.innerHTML=deck.map((card,i)=>`<button type="button" data-card="${i}" class="${matches.includes(i)?'matched':flipped.includes(i)?'revealed':''}" aria-label="Kartu ${i+1}${matches.includes(i)||flipped.includes(i)?': '+card.s:''}" ${matches.includes(i)?'disabled':''}>${matches.includes(i)||flipped.includes(i)?card.s:'?'}</button>`).join('');}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-card]');if(!b||lock)return;const i=Number(b.dataset.card);if(flipped.includes(i)||matches.includes(i))return;flipped.push(i);draw();if(flipped.length===2){moves++;$('#memory-moves',root).textContent=moves;const [a,d]=flipped;if(deck[a].s===deck[d].s){matches.push(a,d);flipped=[];$('#memory-matched',root).textContent=`${matches.length/2}/8`;draw();if(matches.length===16){clearInterval(timer);const score=Math.max(100,1000-moves*22-seconds*2);ui.status.textContent=`Semua pasangan ditemukan dalam ${moves} langkah.`;ctx.done(score,'Memory Matrix selesai.');}}else{lock=true;flipTimer=window.setTimeout(()=>{flipped=[];lock=false;draw();},650);}}},{signal:ctx.signal});signalButton('memory-reset',reset,ctx.signal);reset();return ()=>{clearInterval(timer);clearTimeout(flipTimer);};
  }

  function mountMines(root,ctx) {
    const SIZE=8,TOTAL=10;let mines,adj,revealed,flags,over,first,flagMode=false;
    const ui=panel(root,{toolbar:stat('SAFE','0/54','mine-safe')+stat('FLAGS','0/10','mine-flags'),content:'<div class="board mine-board" id="mine-board" role="group" aria-label="Papan Mine Protocol"></div>',controls:btn('FLAG MODE: OFF','mine-flag-mode',true)+btn('NEW FIELD','mine-reset'),help:'Buka sel dengan klik. Klik kanan atau aktifkan Flag Mode di layar sentuh untuk menandai dugaan ranjau.'});const el=$('#mine-board',root);
    function reset(){mines=new Set();while(mines.size<TOTAL)mines.add(randomInt(SIZE*SIZE));adj=Array(SIZE*SIZE).fill(0);revealed=new Set();flags=new Set();over=false;first=true;flagMode=false;mineCount();draw();ui.status.textContent='Field belum dipindai. Pilih sel pertama.';$('#mine-flag-mode',root).textContent='FLAG MODE: OFF';$('#mine-flag-mode',root).setAttribute('aria-pressed','false');}
    function mineCount(){for(let i=0;i<SIZE*SIZE;i++){if(mines.has(i)){adj[i]=0;continue;}const r=Math.floor(i/SIZE),col=i%SIZE;let n=0;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const rr=r+dr,cc=col+dc;if(rr>=0&&rr<SIZE&&cc>=0&&cc<SIZE&&mines.has(rr*SIZE+cc))n++;}adj[i]=n;}}
    function draw(){el.innerHTML=Array.from({length:SIZE*SIZE},(_,i)=>`<button type="button" data-mine="${i}" class="${revealed.has(i)?'revealed':''} ${over&&mines.has(i)?'mine-hit':''}" aria-label="Sel ${i+1}${flags.has(i)?', ditandai':revealed.has(i)?', '+(mines.has(i)?'ranjau':adj[i]||'kosong'):'tertutup'}" ${over||revealed.has(i)?'disabled':''}>${flags.has(i)?'⚑':revealed.has(i)?(mines.has(i)?'✹':adj[i]||''):''}</button>`).join('');$('#mine-safe',root).textContent=`${revealed.size}/${SIZE*SIZE-TOTAL}`;$('#mine-flags',root).textContent=`${flags.size}/${TOTAL}`;}
    function reveal(i){if(over||revealed.has(i)||flags.has(i))return;if(first&&mines.has(i)){mines.delete(i);let replacement=randomInt(SIZE*SIZE);while(replacement===i||mines.has(replacement))replacement=randomInt(SIZE*SIZE);mines.add(replacement);mineCount();}first=false;if(mines.has(i)){over=true;revealed=new Set([...revealed,...mines]);ui.status.textContent='Ranjau aktif. Field gagal; mulai field baru.';draw();ctx.done(revealed.size===SIZE*SIZE?0:revealed.size*10,'Mine Protocol gagal.');return;}const queue=[i];while(queue.length){const p=queue.pop();if(revealed.has(p)||flags.has(p)||mines.has(p))continue;revealed.add(p);if(adj[p]===0){const r=Math.floor(p/SIZE),col=p%SIZE;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const rr=r+dr,cc=col+dc;if(rr>=0&&rr<SIZE&&cc>=0&&cc<SIZE){const n=rr*SIZE+cc;if(!revealed.has(n))queue.push(n);}}}}if(revealed.size===SIZE*SIZE-TOTAL){over=true;ui.status.textContent='Semua sel aman berhasil dibuka.';ctx.done(1000-flags.size*10,'Mine Protocol dimenangkan.');}draw();}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-mine]');if(!b)return;const i=Number(b.dataset.mine);if(flagMode){if(flags.has(i))flags.delete(i);else flags.add(i);draw();return;}reveal(i);},{signal:ctx.signal});el.addEventListener('contextmenu',e=>{const b=e.target.closest('[data-mine]');if(!b)return;e.preventDefault();const i=Number(b.dataset.mine);if(!over&&!revealed.has(i)){if(flags.has(i))flags.delete(i);else flags.add(i);draw();}},{signal:ctx.signal});signalButton('mine-flag-mode',()=>{flagMode=!flagMode;$('#mine-flag-mode',root).textContent=`FLAG MODE: ${flagMode?'ON':'OFF'}`;$('#mine-flag-mode',root).setAttribute('aria-pressed',String(flagMode));},ctx.signal);signalButton('mine-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountLights(root,ctx) {
    const N=5;let board,moves,over;const ui=panel(root,{toolbar:stat('MOVES','0','lights-moves')+stat('LIGHTS ON','0','lights-on')+stat('GOAL','ALL OFF'),content:'<div class="board lights-board" id="lights-board" role="group" aria-label="Lights Out"></div>',controls:btn('NEW PATTERN','lights-reset'),help:'Satu pilihan membalik sel yang dipilih dan tetangga di atas, bawah, kiri, kanan.'});const el=$('#lights-board',root);
    function reset(){board=Array(N*N).fill(false);for(let i=0;i<9;i++){const index=randomInt(N*N);toggle(index,false);}moves=0;over=false;draw();ui.status.textContent='Matikan semua lampu. Pola dibuat lokal.';}
    function toggle(i,change=true){const r=Math.floor(i/N),col=i%N;[ [r,col],[r-1,col],[r+1,col],[r,col-1],[r,col+1] ].forEach(([rr,cc])=>{if(rr>=0&&rr<N&&cc>=0&&cc<N)board[rr*N+cc]=!board[rr*N+cc];});if(change)moves++;}
    function draw(){el.innerHTML=board.map((v,i)=>`<button type="button" data-light="${i}" class="${v?'lit':''}" aria-label="Lampu ${i+1}: ${v?'menyala':'mati'}" ${over?'disabled':''}></button>`).join('');$('#lights-moves',root).textContent=moves;$('#lights-on',root).textContent=board.filter(Boolean).length;}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-light]');if(!b||over)return;toggle(Number(b.dataset.light));draw();if(board.every(v=>!v)){over=true;ui.status.textContent=`Semua lampu mati dalam ${moves} langkah.`;ctx.done(Math.max(100,1000-moves*25),'Lights Out berhasil.');draw();}},{signal:ctx.signal});signalButton('lights-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountTicTacToe(root,ctx) {
    const ui=panel(root,{toolbar:stat('YOU','X')+stat('CPU','O')+stat('MODE','MINIMAX'),content:'<div class="board ttt-board" id="ttt-board" role="group" aria-label="Papan Tic Tac Toe"></div>',controls:btn('NEW ROUND','ttt-reset'),help:'Kamu bermain sebagai X. CPU menggunakan pencarian minimax untuk mengambil keputusan.'});const el=$('#ttt-board',root);let board,over,botTimer;
    function reset(){clearTimeout(botTimer);board=Array(9).fill('');over=false;draw();ui.status.textContent='Giliran kamu (X).';}
    function winner(b){for(const [a,d,e] of [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]])if(b[a]&&b[a]===b[d]&&b[a]===b[e])return b[a];return b.every(Boolean)?'draw':null;}
    function mini(b,turn,depth){const w=winner(b);if(w==='O')return 10-depth;if(w==='X')return depth-10;if(w==='draw')return 0;let best=turn==='O'?-Infinity:Infinity;for(let i=0;i<9;i++)if(!b[i]){b[i]=turn;const val=mini(b,turn==='O'?'X':'O',depth+1);b[i]='';best=turn==='O'?Math.max(best,val):Math.min(best,val);}return best;}
    function draw(){el.innerHTML=board.map((v,i)=>`<button type="button" data-ttt="${i}" aria-label="Sel ${i+1}${v?', '+v:' kosong'}" ${v||over?'disabled':''}>${v?`<span style="color:${v==='X'?'var(--pink)':'var(--cyan)'}">${v}</span>`:''}</button>`).join('');}
    function finish(w){over=true;const note=w==='X'?'Kamu menang.':w==='O'?'CPU menang.':'Hasil seri.';ui.status.textContent=note;ctx.done(w==='X'?300:w==='draw'?100:0,`Gridlock: ${note}`);draw();}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-ttt]');if(!b||over)return;const i=Number(b.dataset.ttt);if(board[i])return;board[i]='X';draw();let w=winner(board);if(w){finish(w);return;}ui.status.textContent='CPU sedang memilih...';botTimer=setTimeout(()=>{if(over)return;let best=-Infinity,move=-1;for(let j=0;j<9;j++)if(!board[j]){board[j]='O';const val=mini(board,'X',0);board[j]='';if(val>best){best=val;move=j;}}if(move>=0)board[move]='O';draw();w=winner(board);if(w)finish(w);else ui.status.textContent='Giliran kamu (X).';},160);},{signal:ctx.signal});signalButton('ttt-reset',reset,ctx.signal);reset();return ()=>clearTimeout(botTimer);
  }

  function mountConnect4(root,ctx) {
    const ui=panel(root,{toolbar:stat('YOU','MAGENTA')+stat('CPU','CYAN')+stat('TARGET','4 CONNECT'),content:'<div class="board connect-board" id="connect-board" role="group" aria-label="Connect Four board"></div>',controls:btn('NEW MATCH','connect-reset'),help:'Pilih kolom; chip jatuh ke ruang kosong paling bawah. Empat berurutan berarti menang.'});const el=$('#connect-board',root);let board,over,botTimer;
    function reset(){clearTimeout(botTimer);board=Array.from({length:6},()=>Array(7).fill(0));over=false;draw();ui.status.textContent='Kamu mulai (magenta).';}
    function draw(){el.innerHTML=board.map((row,r)=>row.map((value,col)=>`<button type="button" data-col="${col}" data-row="${r}" class="${value===1?'p1':value===2?'p2':''}" aria-label="Baris ${r+1}, kolom ${col+1}${value===1?', chip kamu':value===2?', chip CPU':', kosong'}" ${over||board[0][col]?'disabled':''}>${value?'●':''}</button>`).join('')).join('');}
    function drop(col,player){for(let row=5;row>=0;row--)if(!board[row][col]){board[row][col]=player;return [row,col];}return null;}
    function won(p){for(let r=0;r<6;r++)for(let c=0;c<7;c++)if(board[r][c]===p){for(const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]){let n=1;for(let k=1;k<4;k++){const rr=r+dr*k,cc=c+dc*k;if(rr<0||rr>=6||cc<0||cc>=7||board[rr][cc]!==p)break;n++;}if(n>=4)return true;}}return false;}
    function finish(player){over=true;const text=player===1?'Kamu menyusun empat chip.':player===2?'CPU mendapatkan empat chip.':'Papan penuh, hasil seri.';ui.status.textContent=text;ctx.done(player===1?400:player===0?100:0,`Four in a Row: ${text}`);draw();}
    function aiMove(){if(over)return;let chosen=-1;for(let col=0;col<7;col++){if(board[0][col])continue;const spot=drop(col,2);if(won(2)){chosen=col;board[spot[0]][spot[1]]=0;break;}board[spot[0]][spot[1]]=0;}if(chosen<0){for(let col=0;col<7;col++){if(board[0][col])continue;const spot=drop(col,1);if(won(1)){chosen=col;board[spot[0]][spot[1]]=0;break;}board[spot[0]][spot[1]]=0;}}if(chosen<0){const options=[3,2,4,1,5,0,6].filter(c=>!board[0][c]);chosen=options[0]??-1;}if(chosen>=0){drop(chosen,2);draw();if(won(2))finish(2);else if(board[0].every(Boolean))finish(0);else ui.status.textContent='Giliran kamu (magenta).';}}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-col]');if(!b||over)return;const col=Number(b.dataset.col);if(board[0][col])return;drop(col,1);draw();if(won(1)){finish(1);return;}if(board[0].every(Boolean)){finish(0);return;}ui.status.textContent='CPU sedang memilih...';botTimer=setTimeout(aiMove,190);},{signal:ctx.signal});signalButton('connect-reset',reset,ctx.signal);reset();return ()=>clearTimeout(botTimer);
  }

  function mountRPS(root,ctx) {
    const ui=panel(root,{toolbar:stat('ROUND','1 / 5','rps-round')+stat('YOU','0','rps-you')+stat('CPU','0','rps-cpu'),content:'<div class="choice-row"><button type="button" class="choice-button" data-rps="rock" aria-label="Batu">✊<span>BATU</span></button><button type="button" class="choice-button" data-rps="paper" aria-label="Kertas">✋<span>KERTAS</span></button><button type="button" class="choice-button" data-rps="scissors" aria-label="Gunting">✌<span>GUNTING</span></button></div><div class="game-result" id="rps-result"></div>',controls:btn('RESET MATCH','rps-reset'),help:'Lima ronde per pertandingan. Jika skor seri, ronde tambahan tidak otomatis dijalankan.'});let round,you,cpu,over;
    const emojis={rock:'✊',paper:'✋',scissors:'✌'};
    function reset(){round=1;you=0;cpu=0;over=false;update();$('#rps-result',root).textContent='Pilih langkah pertama.';ui.status.textContent='Match best-of-five dimulai.';$$('[data-rps]',root).forEach(b=>b.disabled=false);}
    function update(){$('#rps-round',root).textContent=`${Math.min(round,5)} / 5` ;$('#rps-you',root).textContent=you;$('#rps-cpu',root).textContent=cpu;}
    root.addEventListener('click',e=>{const b=e.target.closest('[data-rps]');if(!b||over)return;const choice=b.dataset.rps,opts=['rock','paper','scissors'],bot=opts[randomInt(3)];let result=choice===bot?'DRAW':(choice==='rock'&&bot==='scissors'||choice==='paper'&&bot==='rock'||choice==='scissors'&&bot==='paper')?'WIN':'LOSE';if(result==='WIN')you++;if(result==='LOSE')cpu++;$('#rps-result',root).innerHTML=`<span class="result-chip">YOU <strong>${emojis[choice]}</strong></span><span class="result-chip">CPU <strong>${emojis[bot]}</strong></span><span class="result-chip">${result}</span>`;round++;update();if(round>5){over=true;$$('[data-rps]',root).forEach(x=>x.disabled=true);const note=you>cpu?'Kemenangan di pihakmu.':you<cpu?'CPU memenangkan match.':'Match berakhir imbang.';ui.status.textContent=note;ctx.done(you*100+Math.max(0,(you-cpu)*25),`Rock Paper Scissors: ${note}`);}else ui.status.textContent=`Ronde ${round-1}: ${result.toLowerCase()}. Pilih langkah berikutnya.`;},{signal:ctx.signal});signalButton('rps-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountNumber(root,ctx) {
    const ui=panel(root,{toolbar:stat('ATTEMPTS','0','number-attempts')+stat('RANGE','1–100')+stat('MODE','DECODE'),content:'<form class="game-form" id="number-form"><label class="sr-only" for="number-input">Tebakan angka</label><input class="game-input" id="number-input" type="number" min="1" max="100" step="1" placeholder="1 — 100" required inputmode="numeric"><button class="game-btn" type="submit">SUBMIT GUESS ↗</button></form><div class="game-result" id="number-hint"></div>',controls:btn('NEW NUMBER','number-reset',true),help:'Setiap angka bulat 1–100. Coba selesaikan dengan tebakan sesedikit mungkin.'});let answer,attempts,over;
    function reset(){answer=randomInt(100)+1;attempts=0;over=false;$('#number-attempts',root).textContent='0';$('#number-hint',root).textContent='Angka rahasia telah dienkripsi.';$('#number-input',root).disabled=false;$('#number-form button',root).disabled=false;ui.status.textContent='Masukkan tebakan pertama.';$('#number-input',root).value='';}
    $('#number-form',root).addEventListener('submit',e=>{e.preventDefault();if(over)return;const input=$('#number-input',root),value=Number(input.value);if(!Number.isInteger(value)||value<1||value>100){ui.status.textContent='Masukkan angka bulat antara 1 dan 100.';return;}attempts++;$('#number-attempts',root).textContent=attempts;if(value===answer){over=true;const score=Math.max(100,1100-attempts*100);$('#number-hint',root).textContent=`ACCESS GRANTED — ${answer}`;ui.status.textContent=`Tepat dalam ${attempts} tebakan.`;input.disabled=true;$('#number-form button',root).disabled=true;ctx.done(score,'Number Decoder terpecahkan.');}else{$('#number-hint',root).textContent=value<answer?'▲ Terlalu rendah — cari angka yang lebih tinggi.':'▼ Terlalu tinggi — cari angka yang lebih rendah.';ui.status.textContent='Petunjuk diperbarui. Coba lagi.';input.select();}}, {signal:ctx.signal});signalButton('number-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountReaction(root,ctx) {
    const ui=panel(root,{toolbar:stat('BEST POINTS',formatScore(ctx.getBest()??0))+stat('TARGET','GREEN SIGNAL'),content:'<button type="button" class="reaction-pad" id="reaction-pad">PRESS START<br><small>READY WHEN YOU ARE</small></button>',controls:btn('START TEST','reaction-start'),help:'Setelah mulai, tunggu hingga panel berubah hijau. Menekan terlalu cepat membatalkan percobaan.'});const pad=$('#reaction-pad',root);let stateName='idle',timer,startedAt=0,delay=0;
    function clear(){clearTimeout(timer);timer=null;}
    function reset(){clear();stateName='idle';pad.className='reaction-pad';pad.innerHTML='PRESS START<br><small>READY WHEN YOU ARE</small>';pad.disabled=true;ui.status.textContent='Siap mengukur refleks.';}
    function start(){clear();stateName='waiting';pad.disabled=false;pad.className='reaction-pad waiting';pad.innerHTML='WAIT FOR GREEN<br><small>DON’T TAP EARLY</small>';ui.status.textContent='Menunggu sinyal acak...';delay=1300+randomInt(2800);timer=setTimeout(()=>{if(stateName!=='waiting')return;stateName='ready';startedAt=performance.now();pad.className='reaction-pad ready';pad.innerHTML='NOW!<br><small>PRESS THE PANEL</small>';},delay);}
    pad.addEventListener('click',()=>{if(stateName==='waiting'){clear();stateName='idle';pad.className='reaction-pad too-soon';pad.innerHTML='TOO EARLY<br><small>WAIT FOR GREEN NEXT TIME</small>';ui.status.textContent='Terlalu cepat. Mulai tes baru.';}else if(stateName==='ready'){const ms=Math.round(performance.now()-startedAt),points=Math.max(0,1500-ms);stateName='result';pad.className='reaction-pad';pad.innerHTML=`${ms} MS<br><small>REACTION CAPTURED</small>`;ui.status.textContent=`Waktu reaksi ${ms} ms. Skor refleks ${points}.`;ctx.done(points,`Reflex Overdrive: ${ms} ms.`);}}, {signal:ctx.signal});
    document.addEventListener('visibilitychange',()=>{if(document.hidden&&(stateName==='waiting'||stateName==='ready')){clear();stateName='idle';pad.disabled=true;pad.className='reaction-pad';pad.innerHTML='TEST PAUSED<br><small>RETURN AND START AGAIN</small>';ui.status.textContent='Tes dibatalkan karena tab tidak terlihat. Mulai lagi.';}},{signal:ctx.signal});
    signalButton('reaction-start',start,ctx.signal);reset();return clear;
  }

  function mountSimon(root,ctx) {
    const ui=panel(root,{toolbar:stat('LEVEL','0','simon-level')+stat('INPUT','0','simon-input')+stat('MODE','MEMORY'),content:'<div class="simon-board" id="simon-board" role="group" aria-label="Empat pad Simon"><button class="simon-pad" data-pad="0" type="button" aria-label="Pad hijau toska"></button><button class="simon-pad" data-pad="1" type="button" aria-label="Pad magenta"></button><button class="simon-pad" data-pad="2" type="button" aria-label="Pad ungu"></button><button class="simon-pad" data-pad="3" type="button" aria-label="Pad lime"></button></div>',controls:btn('START SEQUENCE','simon-start')+btn('RESET','simon-reset',true),help:'Perhatikan seluruh urutan cahaya, lalu ulangi tanpa mengubah urutan.'});const el=$('#simon-board',root);let seq,idx,level,playing,over,timers=[];
    function clearTimers(){timers.forEach(clearTimeout);timers=[];}
    function flash(n,duration=260){const b=$(`[data-pad="${n}"]`,el);if(!b)return;b.classList.add('lit');const t=setTimeout(()=>b.classList.remove('lit'),duration);timers.push(t);}
    function update(){$('#simon-level',root).textContent=level;$('#simon-input',root).textContent=idx;}
    function reset(){clearTimers();seq=[];idx=0;level=0;playing=false;over=false;update();ui.status.textContent='Mulai untuk menerima urutan pertama.';}
    function playSequence(){playing=true;idx=0;update();ui.status.textContent='Amati urutan sinyal...';seq.forEach((n,i)=>{const t=setTimeout(()=>flash(n),360+i*560);timers.push(t);});const ready=setTimeout(()=>{playing=false;ui.status.textContent='Giliran kamu. Ulangi urutan dari awal.';},seq.length*560+450);timers.push(ready);}
    function nextLevel(){level++;seq.push(randomInt(4));update();playSequence();}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-pad]');if(!b||playing||over||level===0)return;const n=Number(b.dataset.pad);flash(n,140);if(n!==seq[idx]){over=true;playing=false;ui.status.textContent=`Sinyal keliru pada level ${level}.`;ctx.done((level-1)*100,'Signal Sequence gagal.');return;}idx++;update();if(idx===seq.length){ui.status.textContent='Tepat. Bersiap untuk urutan berikutnya.';const t=setTimeout(nextLevel,500);timers.push(t);}},{signal:ctx.signal});
    document.addEventListener('visibilitychange',()=>{if(document.hidden&&playing){clearTimers();playing=false;seq=[];idx=0;level=0;update();ui.status.textContent='Urutan dihentikan karena tab tidak terlihat. Mulai ulang.';}},{signal:ctx.signal});
    signalButton('simon-start',()=>{reset();nextLevel();},ctx.signal);signalButton('simon-reset',reset,ctx.signal);reset();return clearTimers;
  }

  function mountMath(root,ctx) {
    const ui=panel(root,{toolbar:stat('QUESTION','1 / 10','math-question')+stat('CORRECT','0','math-correct')+stat('SCORE','0','math-score'),content:'<form class="game-form" id="math-form"><label class="sr-only" for="math-answer">Jawaban aritmetika</label><span id="math-prompt" style="font:700 clamp(24px,5vw,40px) var(--mono);color:var(--cyan);align-self:center;min-width:150px;text-align:center">7 × 8 = ?</span><input class="game-input" id="math-answer" type="number" step="1" placeholder="Jawaban" inputmode="numeric" required><button class="game-btn" type="submit">CHECK</button></form>',controls:btn('NEW SET','math-reset',true),help:'Sepuluh soal campuran penjumlahan, pengurangan, dan perkalian. Skor 100 untuk setiap jawaban benar.'});let q,correct,index,over;
    function makeQuestion(){const ops=['+','−','×'],op=ops[randomInt(3)];let a,b,answer;if(op==='+'){a=randomInt(80)+10;b=randomInt(50)+1;answer=a+b;}else if(op==='−'){a=randomInt(80)+20;b=randomInt(a);answer=a-b;}else{a=randomInt(12)+2;b=randomInt(12)+2;answer=a*b;}return {a,b,op,answer};}
    function show(){$('#math-question',root).textContent=`${Math.min(index+1,10)} / 10` ;$('#math-correct',root).textContent=correct;$('#math-score',root).textContent=correct*100;$('#math-prompt',root).textContent=`${q.a} ${q.op} ${q.b} = ?`;$('#math-answer',root).value='';$('#math-answer',root).disabled=over;$('#math-form button',root).disabled=over;}
    function reset(){index=0;correct=0;over=false;q=makeQuestion();show();ui.status.textContent='Sepuluh soal. Fokus pada ketepatan.';}
    $('#math-form',root).addEventListener('submit',e=>{e.preventDefault();if(over)return;const val=Number($('#math-answer',root).value);if(!Number.isFinite(val)||$('#math-answer',root).value.trim()===''){ui.status.textContent='Masukkan jawaban angka yang valid.';return;}const isCorrect=val===q.answer;if(isCorrect)correct++;index++;if(index>=10){over=true;show();ui.status.textContent=`Selesai: ${correct} dari 10 jawaban benar.`;ctx.done(correct*100,'Quick Math selesai.');}else{q=makeQuestion();show();ui.status.textContent=isCorrect?'Benar. Lanjut.':'Jawaban dicatat. Soal berikutnya.';}}, {signal:ctx.signal});signalButton('math-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountWhack(root,ctx) {
    const ui=panel(root,{toolbar:stat('SCORE','0','whack-score')+stat('TIME','30s','whack-time')+stat('HITS','0','whack-hits'),content:'<div class="board mole-board" id="mole-board" role="group" aria-label="Glitch Hunter board"></div>',controls:btn('START HUNT','whack-start')+btn('RESET','whack-reset',true),help:'Tangkap glyph yang menyala. Sesi berjalan selama 30 detik setelah tombol Start.'});const el=$('#mole-board',root);let active=-1,score,hits,seconds,started,interval,spawnInterval;
    function clear(){clearInterval(interval);clearInterval(spawnInterval);interval=null;spawnInterval=null;}
    function draw() {el.innerHTML=Array.from({length:9},(_,i)=>`<button type="button" data-mole="${i}" class="${active===i&&started?'active':''}" aria-label="Sel ${i+1}${active===i&&started?', glitch aktif':''}" ${!started?'disabled':''}>${active===i&&started?'✦':''}</button>`).join('');$('#whack-score',root).textContent=score;$('#whack-time',root).textContent=`${seconds}s`;$('#whack-hits',root).textContent=hits;}
    function reset(){clear();active=-1;score=0;hits=0;seconds=30;started=false;draw();ui.status.textContent='Tekan Start Hunt ketika siap.';}
    function start(){clear();score=0;hits=0;seconds=30;started=true;active=randomInt(9);draw();ui.status.textContent='Hunt aktif! Tangkap sebanyak mungkin.';spawnInterval=setInterval(()=>{if(started&&!document.hidden)active=randomInt(9);draw();},620);interval=setInterval(()=>{if(document.hidden)return;seconds--;if(seconds<=0){seconds=0;started=false;clear();active=-1;ui.status.textContent=`Waktu habis. ${hits} glitch tertangkap.`;ctx.done(score,'Glitch Hunter selesai.');}draw();},1000);}
    el.addEventListener('click',e=>{const b=e.target.closest('[data-mole]');if(!b||!started)return;const i=Number(b.dataset.mole);if(i===active){hits++;score+=10;active=randomInt(9);ui.status.textContent='Glitch berhasil ditangkap.';}else{score=Math.max(0,score-2);ui.status.textContent='Tidak ada glitch di sel ini.';}draw();},{signal:ctx.signal});signalButton('whack-start',start,ctx.signal);signalButton('whack-reset',reset,ctx.signal);reset();return clear;
  }

  function mountWord(root,ctx) {
    const words=['NEON','ARCADE','PIXEL','MATRIX','CYBER','SIGNAL','LASER','ROBOT','FUTURE','GLITCH','VECTOR','CIRCUIT'];let word,answer,round,score,over;
    const ui=panel(root,{toolbar:stat('ROUND','1 / 8','word-round')+stat('CORRECT','0','word-correct')+stat('SCORE','0','word-score'),content:'<div style="text-align:center;padding:13px 0 3px"><p class="eyebrow" style="justify-content:center">DECODE THE WORD</p><div id="word-scramble" style="font:800 clamp(27px,6vw,46px) var(--mono);letter-spacing:.18em;color:var(--cyan);text-shadow:0 0 20px rgba(73,247,226,.15)">NENO</div><p id="word-hint" style="font-size:10px;color:var(--muted)">Tema: cyber / arcade</p></div><form class="game-form" id="word-form"><label class="sr-only" for="word-answer">Kata jawaban</label><input class="game-input" id="word-answer" type="text" autocomplete="off" autocapitalize="characters" maxlength="10" placeholder="KETIK KATA" required><button class="game-btn" type="submit">DECODE</button></form>',controls:btn('NEW SET','word-reset',true),help:'Delapan kata dalam set. Kata memakai kosakata teknologi umum; seluruh data disertakan lokal.'});
    function scramble(w){let s=w.split('');for(let i=s.length-1;i>0;i--){const j=randomInt(i+1);[s[i],s[j]]=[s[j],s[i]];}if(s.join('')===w)s.push(s.shift());return s.join('');}
    function next(){word=words[randomInt(words.length)];let scrambleText=scramble(word);let tries=0;while(scrambleText===word&&tries++<5)scrambleText=scramble(word);$('#word-scramble',root).textContent=scrambleText;$('#word-answer',root).value='';$('#word-answer',root).disabled=over;$('#word-form button',root).disabled=over;$('#word-round',root).textContent=`${Math.min(round+1,8)} / 8`;}
    function reset(){round=0;score=0;answer=0;over=false;$('#word-correct',root).textContent='0';$('#word-score',root).textContent='0';next();ui.status.textContent='Pecahkan huruf acak menjadi kata valid.';}
    $('#word-form',root).addEventListener('submit',e=>{e.preventDefault();if(over)return;const val=$('#word-answer',root).value.trim().toUpperCase();if(!val){ui.status.textContent='Masukkan kata terlebih dahulu.';return;}if(val===word){score+=100;answer++;ui.status.textContent='DECODE SUCCESS. +100';}else ui.status.textContent=`Belum tepat. Kata yang dicari: ${word}.`;round++;$('#word-correct',root).textContent=answer;$('#word-score',root).textContent=score;if(round>=8){over=true;next();ui.status.textContent=`Set selesai. ${answer} dari 8 kata benar.`;ctx.done(score,'Word Scrambler selesai.');}else next();}, {signal:ctx.signal});signalButton('word-reset',reset,ctx.signal);reset();return ()=>{};
  }

  function mountColor(root,ctx) {
    const colorSet=[{name:'MERAH',hex:'#ff426f'},{name:'CYAN',hex:'#49f7e2'},{name:'LIME',hex:'#d5ff5b'},{name:'UNGU',hex:'#a88bff'},{name:'ORANYE',hex:'#ff9d42'}];let target,score,seconds,started,interval,locked=false;
    const ui=panel(root,{toolbar:stat('SCORE','0','color-score')+stat('TIME','30s','color-time')+stat('STREAK','0','color-streak'),content:'<div style="text-align:center;padding:5px 0 12px"><p class="eyebrow" style="justify-content:center">MATCH THE INK, NOT THE WORD</p><div id="color-word" style="font:900 clamp(29px,7vw,47px) var(--mono);letter-spacing:.05em;padding:13px 0">CYAN</div><p style="font-size:10px;color:var(--muted);margin:0">Pilih warna tinta yang terlihat.</p></div><div class="choice-row" id="color-choices"></div>',controls:btn('START OVERRIDE','color-start')+btn('RESET','color-reset',true),help:'Pilih label warna yang sesuai dengan tinta pada kata. Bukan makna teksnya.'});
    const choiceEl=$('#color-choices',root),wordEl=$('#color-word',root);
    function newTarget(){const ink=colorSet[randomInt(colorSet.length)];let word=colorSet[randomInt(colorSet.length)];if(word.name===ink.name)word=colorSet[(colorSet.indexOf(word)+1)%colorSet.length];target=ink;wordEl.textContent=word.name;wordEl.style.color=ink.hex;choiceEl.innerHTML=shuffle([...colorSet]).map(c=>`<button type="button" class="game-btn secondary" data-color="${c.name}" style="min-width:76px;border-color:${c.hex}55;color:${c.hex}" ${!started?'disabled':''}>${c.name}</button>`).join('');}
    function update(){ $('#color-score',root).textContent=score;$('#color-time',root).textContent=`${seconds}s`;$('#color-streak',root).textContent=score/10; }
    function clear(){clearInterval(interval);interval=null;}
    function reset(){clear();started=false;score=0;seconds=30;locked=false;newTarget();update();ui.status.textContent='Tekan Start Override untuk memulai.';}
    function start(){clear();started=true;score=0;seconds=30;newTarget();update();ui.status.textContent='Match warna tinta. Jangan baca kata.';interval=setInterval(()=>{if(document.hidden)return;seconds--;update();if(seconds<=0){seconds=0;started=false;clear();newTarget();update();ui.status.textContent=`Waktu habis. Skor akhir ${score}.`;ctx.done(score,'Color Override selesai.');}},1000);}
    choiceEl.addEventListener('click',e=>{const b=e.target.closest('[data-color]');if(!b||!started||locked)return;if(b.dataset.color===target.name){score+=10;ui.status.textContent='Correct color. +10';}else{score=Math.max(0,score-5);ui.status.textContent='Wrong color. -5';}newTarget();update();},{signal:ctx.signal});signalButton('color-start',start,ctx.signal);signalButton('color-reset',reset,ctx.signal);reset();return clear;
  }

  /* App shell interactions */
  grid.addEventListener('click',e=>{const fav=e.target.closest('[data-favorite]');if(fav){e.stopPropagation();toggleFavorite(fav.dataset.favorite);return;}const play=e.target.closest('[data-play]');if(play)openGame(play.dataset.play,play);});
  $$('.category-chip').forEach(button=>button.addEventListener('click',()=>{currentCategory=button.dataset.category;renderLibrary();}));
  $('#game-search').addEventListener('input',renderLibrary);
  $('#favorites-filter').addEventListener('click',()=>{favoritesOnly=!favoritesOnly;renderLibrary();});
  $('#reset-filters').addEventListener('click',()=>{currentCategory='all';favoritesOnly=false;$('#game-search').value='';renderLibrary();});
  $('#close-game').addEventListener('click',()=>closeGame());
  overlay.addEventListener('click',e=>{if(e.target.matches('[data-close-game="true"]'))closeGame();});
  document.addEventListener('keydown',e=>{if(!overlay.hidden&&e.key==='Escape'){e.preventDefault();closeGame();return;}if(!overlay.hidden&&e.key==='Tab'){const focusables=$$('button:not(:disabled),input:not(:disabled),a[href]',overlay).filter(el=>el.offsetParent!==null);if(!focusables.length)return;const first=focusables[0],last=focusables[focusables.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}if(e.key==='/'&&overlay.hidden&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();$('#game-search').focus();}}, {capture:true});
  $('#motion-toggle').addEventListener('click',()=>{const reduced=document.body.classList.toggle('reduce-motion');$('#motion-toggle').setAttribute('aria-pressed',String(reduced));$('#motion-toggle').title=reduced?'Aktifkan kembali animasi':'Kurangi animasi';toast(reduced?'Mode animasi rendah aktif.':'Mode animasi rendah nonaktif.');});
  $('#clear-records').addEventListener('click',()=>{const yes=window.confirm('Hapus semua skor, riwayat sesi, dan favorit yang tersimpan di browser ini?');if(!yes)return;state=defaultState();saveState();renderLibrary();toast('Rekam lokal berhasil direset.');});
  function updateConnection(){const online=navigator.onLine;connectionLabel.textContent=online?'LOCAL READY':'OFFLINE MODE';const dot=$('.connection-pill i');if(dot){dot.style.background=online?'var(--lime)':'var(--pink)';dot.style.boxShadow=online?'0 0 9px rgba(213,255,91,.55)':'0 0 9px rgba(255,66,111,.55)';}}
  window.addEventListener('online',updateConnection);window.addEventListener('offline',updateConnection);updateConnection();renderLibrary();

  // PWA install is optional. The actual games require no network at runtime.
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;$('#install-button').hidden=false;});
  $('#install-button').addEventListener('click',async()=>{if(!deferredInstallPrompt){toast('Gunakan menu browser: Add to Home Screen / Install App.');return;}deferredInstallPrompt.prompt();try{await deferredInstallPrompt.userChoice;}catch(_){}deferredInstallPrompt=null;$('#install-button').hidden=true;});
  if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost' || location.hostname==='127.0.0.1')){
    window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').then(()=>{}).catch(error=>console.warn('Service worker registration unavailable:',error)));
  }
})();
